import './App.css';
import CrudTable from './components/tables/CrudTable';

function App() {


  return (
    <div className="App">
    <CrudTable />
    </div>
  );
}

export default App;
